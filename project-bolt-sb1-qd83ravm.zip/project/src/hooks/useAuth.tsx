import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { User, UserSubscription } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
  updateSubscription: (subscription: UserSubscription) => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem('eurojobs-user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: '1',
      email,
      name: email.split('@')[0],
      savedJobs: [],
      appliedJobs: [],
      subscription: {
        plan: 'free',
        status: 'active',
        startDate: new Date().toISOString(),
        paymentMethod: 'stripe',
        subscriptionId: 'free_plan'
      }
    };
    
    setUser(mockUser);
    localStorage.setItem('eurojobs-user', JSON.stringify(mockUser));
    setLoading(false);
  };

  const register = async (email: string, password: string, name: string) => {
    setLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockUser: User = {
      id: Date.now().toString(),
      email,
      name,
      savedJobs: [],
      appliedJobs: [],
      subscription: {
        plan: 'free',
        status: 'active',
        startDate: new Date().toISOString(),
        paymentMethod: 'stripe',
        subscriptionId: 'free_plan'
      }
    };
    
    setUser(mockUser);
    localStorage.setItem('eurojobs-user', JSON.stringify(mockUser));
    setLoading(false);
  };

  const updateSubscription = (subscription: UserSubscription) => {
    if (user) {
      const updatedUser = { ...user, subscription };
      setUser(updatedUser);
      localStorage.setItem('eurojobs-user', JSON.stringify(updatedUser));
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('eurojobs-user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, updateSubscription, loading }}>
      {children}
    </AuthContext.Provider>
  );
};