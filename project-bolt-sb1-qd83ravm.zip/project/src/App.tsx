import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { JobList } from './components/JobList';
import { AuthModal } from './components/AuthModal';
import { ApiConfigPanel } from './components/ApiConfigPanel';
import { PricingModal } from './components/PricingModal';
import { SubscriptionStatus } from './components/SubscriptionStatus';
import { AuthProvider, useAuth } from './hooks/useAuth.tsx';
import { useJobs } from './hooks/useJobs';
import { usePayments } from './hooks/usePayments';
import { SearchFilters, ApiConfig, SubscriptionPlan } from './types';
import { Settings, Crown } from 'lucide-react';

function AppContent() {
  const { user, updateSubscription } = useAuth();
  const { jobs, loading, error, searchJobs } = useJobs();
  const { createSubscription } = usePayments();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [apiConfigOpen, setApiConfigOpen] = useState(false);
  const [pricingModalOpen, setPricingModalOpen] = useState(false);
  const [filters, setFilters] = useState<Partial<SearchFilters>>({});
  const [apiConfigs, setApiConfigs] = useState<ApiConfig[]>([]);

  // Load API configs from localStorage
  useEffect(() => {
    const savedConfigs = localStorage.getItem('eurojobs-api-configs');
    if (savedConfigs) {
      setApiConfigs(JSON.parse(savedConfigs));
    }
  }, []);

  // Save API configs to localStorage
  useEffect(() => {
    localStorage.setItem('eurojobs-api-configs', JSON.stringify(apiConfigs));
  }, [apiConfigs]);

  // Initial job search
  useEffect(() => {
    searchJobs({});
  }, []);

  // Search when filters change
  useEffect(() => {
    if (Object.keys(filters).length > 0) {
      searchJobs(filters);
    }
  }, [filters]);

  const handleSearch = (query: string) => {
    setFilters({ ...filters, query });
  };

  const handleFiltersChange = (newFilters: Partial<SearchFilters>) => {
    setFilters(newFilters);
  };

  const handleSaveJob = (jobId: string) => {
    // Implementation for saving jobs
    console.log('Saving job:', jobId);
  };

  const handleSubscribe = async (
    plan: SubscriptionPlan,
    paymentMethod: 'stripe' | 'paypal',
    subscriptionId: string
  ) => {
    try {
      const subscription = await createSubscription(plan.id, paymentMethod, { subscriptionId });
      updateSubscription(subscription);
    } catch (error) {
      console.error('Subscription failed:', error);
    }
  };

  const isPremiumUser = user?.subscription?.plan !== 'free' && user?.subscription?.status === 'active';

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        onSearch={handleSearch}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
      />
      
      <div className="flex">
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          filters={filters}
          onFiltersChange={handleFiltersChange}
        />
        
        <main className="flex-1 p-6">
          <div className="max-w-4xl mx-auto">
            {/* Subscription Status */}
            {user && (
              <div className="mb-6">
                <SubscriptionStatus
                  subscription={user.subscription}
                  onUpgrade={() => setPricingModalOpen(true)}
                  onManage={() => setPricingModalOpen(true)}
                />
              </div>
            )}

            {/* Quick Actions */}
            <div className="flex justify-between items-center mb-6">
              <div className="flex space-x-4">
                {!user && (
                  <button
                    onClick={() => {
                      setAuthMode('login');
                      setAuthModalOpen(true);
                    }}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Sign In
                  </button>
                )}
                {!isPremiumUser && (
                  <button
                    onClick={() => setPricingModalOpen(true)}
                    className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-lg hover:from-purple-700 hover:to-blue-700 transition-colors"
                  >
                    <Crown className="h-4 w-4" />
                    <span>Upgrade to Premium</span>
                  </button>
                )}
                <button
                  onClick={() => setApiConfigOpen(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Settings className="h-4 w-4" />
                  <span>API Config</span>
                </button>
              </div>
              
              <div className="text-sm text-gray-500">
                {apiConfigs.filter(c => c.enabled).length} API sources active
                {isPremiumUser && (
                  <span className="ml-2 px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium">
                    Premium
                  </span>
                )}
              </div>
            </div>

            <JobList
              jobs={jobs}
              loading={loading}
              error={error}
              onSaveJob={handleSaveJob}
              savedJobs={user?.savedJobs || []}
            />
          </div>
        </main>
      </div>

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        mode={authMode}
        onToggleMode={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
      />

      <ApiConfigPanel
        isOpen={apiConfigOpen}
        onClose={() => setApiConfigOpen(false)}
        configs={apiConfigs}
        onConfigsChange={setApiConfigs}
      />

      <PricingModal
        isOpen={pricingModalOpen}
        onClose={() => setPricingModalOpen(false)}
        onSubscribe={handleSubscribe}
      />
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;