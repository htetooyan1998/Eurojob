import React from 'react';
import { Crown, Calendar, CreditCard, AlertCircle } from 'lucide-react';
import { UserSubscription } from '../types';

interface SubscriptionStatusProps {
  subscription?: UserSubscription;
  onUpgrade: () => void;
  onManage: () => void;
}

export const SubscriptionStatus: React.FC<SubscriptionStatusProps> = ({
  subscription,
  onUpgrade,
  onManage
}) => {
  if (!subscription || subscription.plan === 'free') {
    return (
      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Crown className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">Free Plan</h3>
              <p className="text-sm text-gray-600">
                Upgrade to unlock premium features
              </p>
            </div>
          </div>
          <button
            onClick={onUpgrade}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Upgrade
          </button>
        </div>
      </div>
    );
  }

  const isExpiringSoon = subscription.endDate && 
    new Date(subscription.endDate).getTime() - Date.now() < 7 * 24 * 60 * 60 * 1000;

  return (
    <div className={`border rounded-lg p-4 ${
      subscription.status === 'active' 
        ? 'bg-green-50 border-green-200' 
        : 'bg-red-50 border-red-200'
    }`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className={`p-2 rounded-lg ${
            subscription.status === 'active' 
              ? 'bg-green-100' 
              : 'bg-red-100'
          }`}>
            {subscription.status === 'active' ? (
              <Crown className="h-5 w-5 text-green-600" />
            ) : (
              <AlertCircle className="h-5 w-5 text-red-600" />
            )}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="font-medium text-gray-900 capitalize">
                {subscription.plan} Plan
              </h3>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                subscription.status === 'active'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {subscription.status}
              </span>
            </div>
            <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
              {subscription.endDate && (
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4" />
                  <span>
                    {subscription.status === 'active' ? 'Renews' : 'Expired'} on{' '}
                    {new Date(subscription.endDate).toLocaleDateString()}
                  </span>
                </div>
              )}
              <div className="flex items-center space-x-1">
                <CreditCard className="h-4 w-4" />
                <span className="capitalize">{subscription.paymentMethod}</span>
              </div>
            </div>
            {isExpiringSoon && subscription.status === 'active' && (
              <p className="text-sm text-amber-600 mt-1">
                ⚠️ Your subscription expires soon
              </p>
            )}
          </div>
        </div>
        <button
          onClick={onManage}
          className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Manage
        </button>
      </div>
    </div>
  );
};