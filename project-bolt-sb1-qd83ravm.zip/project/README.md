# EuroJobs - European Job Search Platform

A modern job search platform focused on European opportunities with premium features and integrated payment processing.

## Features

### Core Features
- **Job Search**: Advanced search and filtering for European job markets
- **User Authentication**: Secure login and registration system
- **API Integration**: Configure multiple job search APIs
- **Responsive Design**: Mobile-first design with Tailwind CSS

### Premium Features
- **Subscription Plans**: Free, Premium, and Enterprise tiers
- **Payment Processing**: Integrated Stripe and PayPal payments
- **Premium Job Listings**: Access to exclusive job opportunities
- **Advanced Filters**: Enhanced search capabilities
- **Application Tracking**: Track your job applications
- **Resume Builder**: Built-in resume creation tools

## Payment Integration

### Supported Payment Methods
- **Credit/Debit Cards**: Via Stripe integration
- **PayPal**: Direct PayPal payments and subscriptions

### Subscription Plans

#### Free Plan (€0/month)
- Basic job search
- Save up to 10 jobs
- Standard filters
- Weekly email alerts

#### Premium Plan (€19.99/month) - Most Popular
- Advanced job search
- Unlimited saved jobs
- Premium job listings
- Advanced filters
- Daily email alerts
- Application tracking
- Resume builder
- Priority support

#### Enterprise Plan (€49.99/month)
- All Premium features
- Custom API integrations
- Bulk job posting
- Analytics dashboard
- Dedicated account manager
- Custom branding
- Team collaboration
- Advanced reporting

## Setup Instructions

### 1. Environment Variables

Copy `.env.example` to `.env` and configure your payment provider credentials:

```bash
cp .env.example .env
```

### 2. Stripe Setup

1. Create a Stripe account at [stripe.com](https://stripe.com)
2. Get your publishable and secret keys from the Stripe Dashboard
3. Add them to your `.env` file:
   ```
   VITE_STRIPE_PUBLISHABLE_KEY=pk_test_your_key_here
   STRIPE_SECRET_KEY=sk_test_your_key_here
   ```

### 3. PayPal Setup

1. Create a PayPal Developer account at [developer.paypal.com](https://developer.paypal.com)
2. Create a new application to get your Client ID and Secret
3. Add them to your `.env` file:
   ```
   VITE_PAYPAL_CLIENT_ID=your_client_id_here
   PAYPAL_CLIENT_SECRET=your_client_secret_here
   ```

### 4. Webhook Configuration

For production, set up webhooks to handle payment events:

#### Stripe Webhooks
- Endpoint: `https://yourdomain.com/api/webhooks/stripe`
- Events: `invoice.payment_succeeded`, `customer.subscription.deleted`

#### PayPal Webhooks
- Endpoint: `https://yourdomain.com/api/webhooks/paypal`
- Events: `BILLING.SUBSCRIPTION.ACTIVATED`, `BILLING.SUBSCRIPTION.CANCELLED`

## Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## Payment Flow

### Subscription Creation
1. User selects a plan from the pricing modal
2. User chooses payment method (Stripe or PayPal)
3. Payment is processed securely
4. Subscription is activated immediately
5. User gains access to premium features

### Payment Security
- All payments are processed securely through Stripe and PayPal
- No sensitive payment data is stored on our servers
- PCI DSS compliant payment processing
- SSL encryption for all transactions

## Revenue Management

### Payment Tracking
- All payments are logged with detailed information
- Subscription status is tracked in real-time
- Failed payments trigger automatic retry logic
- Detailed analytics and reporting available

### Subscription Management
- Users can upgrade/downgrade plans anytime
- Automatic billing and renewal
- Grace period for failed payments
- Easy cancellation process

## API Integration

The platform supports multiple job search APIs:
- Configure API endpoints in the settings
- Automatic result aggregation
- Premium APIs available for paid users
- Rate limiting and error handling

## Support

For payment-related issues:
- Check the subscription status in your account
- Contact support for billing questions
- Refund policy available in terms of service

## License

This project is proprietary software. All rights reserved.