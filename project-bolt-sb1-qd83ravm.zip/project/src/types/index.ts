export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  country: string;
  type: 'full-time' | 'part-time' | 'contract' | 'internship';
  remote: boolean;
  salary?: {
    min: number;
    max: number;
    currency: string;
  };
  description: string;
  requirements: string[];
  benefits?: string[];
  postedDate: string;
  applicationUrl: string;
  companyLogo?: string;
  tags: string[];
  isPremium?: boolean;
}

export interface User {
  id: string;
  email: string;
  name: string;
  location?: string;
  savedJobs: string[];
  appliedJobs: string[];
  profile?: UserProfile;
  subscription?: UserSubscription;
}

export interface UserProfile {
  title?: string;
  bio?: string;
  skills: string[];
  experience: string;
  education?: string;
  resume?: string;
}

export interface UserSubscription {
  plan: 'free' | 'premium' | 'enterprise';
  status: 'active' | 'cancelled' | 'expired';
  startDate: string;
  endDate?: string;
  paymentMethod: 'stripe' | 'paypal';
  subscriptionId: string;
}

export interface SearchFilters {
  query: string;
  location: string;
  country: string;
  type: string[];
  remote: boolean | null;
  salaryMin?: number;
  salaryMax?: number;
  tags: string[];
  includePremium?: boolean;
}

export interface ApiConfig {
  name: string;
  endpoint: string;
  apiKey?: string;
  headers?: Record<string, string>;
  enabled: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  currency: string;
  interval: 'month' | 'year';
  features: string[];
  popular?: boolean;
}

export interface PaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'succeeded' | 'failed';
  paymentMethod: 'stripe' | 'paypal';
  planId: string;
}