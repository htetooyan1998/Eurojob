import React, { useState } from 'react';
import { X, CreditCard, Loader2, Check } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, CardElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { SubscriptionPlan } from '../types';
import { STRIPE_PUBLISHABLE_KEY, PAYPAL_CLIENT_ID } from '../config/payments';

const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  plan: SubscriptionPlan;
  onSuccess: (paymentMethod: 'stripe' | 'paypal', subscriptionId: string) => void;
}

const StripePaymentForm: React.FC<{
  plan: SubscriptionPlan;
  onSuccess: (subscriptionId: string) => void;
  onError: (error: string) => void;
}> = ({ plan, onSuccess, onError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    
    if (!stripe || !elements) return;
    
    setLoading(true);
    
    const cardElement = elements.getElement(CardElement);
    if (!cardElement) return;

    try {
      // In a real app, you'd create a payment intent on your server
      const { error, paymentMethod } = await stripe.createPaymentMethod({
        type: 'card',
        card: cardElement,
      });

      if (error) {
        onError(error.message || 'Payment failed');
      } else {
        // Simulate successful subscription creation
        const subscriptionId = `sub_${Date.now()}`;
        onSuccess(subscriptionId);
      }
    } catch (err) {
      onError('Payment processing failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-4 border border-gray-200 rounded-lg">
        <CardElement
          options={{
            style: {
              base: {
                fontSize: '16px',
                color: '#424770',
                '::placeholder': {
                  color: '#aab7c4',
                },
              },
            },
          }}
        />
      </div>
      
      <button
        type="submit"
        disabled={!stripe || loading}
        className="w-full flex items-center justify-center py-3 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? (
          <Loader2 className="h-5 w-5 animate-spin" />
        ) : (
          <>
            <CreditCard className="h-5 w-5 mr-2" />
            Pay €{plan.price} with Card
          </>
        )}
      </button>
    </form>
  );
};

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  plan,
  onSuccess
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'stripe' | 'paypal'>('stripe');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const handleStripeSuccess = (subscriptionId: string) => {
    setSuccess(true);
    setTimeout(() => {
      onSuccess('stripe', subscriptionId);
      onClose();
    }, 2000);
  };

  const handlePayPalSuccess = (details: any) => {
    setSuccess(true);
    setTimeout(() => {
      onSuccess('paypal', details.subscriptionID || `pp_${Date.now()}`);
      onClose();
    }, 2000);
  };

  if (!isOpen) return null;

  if (success) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg max-w-md w-full p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Payment Successful!</h3>
          <p className="text-gray-600">
            Welcome to {plan.name}! Your subscription is now active.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">
              Subscribe to {plan.name}
            </h2>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div className="p-6">
          {/* Plan Summary */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-gray-900">{plan.name} Plan</span>
              <span className="text-2xl font-bold text-gray-900">
                €{plan.price}
                <span className="text-sm font-normal text-gray-500">/{plan.interval}</span>
              </span>
            </div>
            <ul className="text-sm text-gray-600 space-y-1">
              {plan.features.slice(0, 3).map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2 flex-shrink-0" />
                  {feature}
                </li>
              ))}
              {plan.features.length > 3 && (
                <li className="text-gray-500">+{plan.features.length - 3} more features</li>
              )}
            </ul>
          </div>

          {/* Payment Method Selection */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-900 mb-3">Payment Method</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setPaymentMethod('stripe')}
                className={`p-3 border rounded-lg text-center transition-colors ${
                  paymentMethod === 'stripe'
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <CreditCard className="h-5 w-5 mx-auto mb-1" />
                <span className="text-sm font-medium">Credit Card</span>
              </button>
              <button
                onClick={() => setPaymentMethod('paypal')}
                className={`p-3 border rounded-lg text-center transition-colors ${
                  paymentMethod === 'paypal'
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="h-5 w-5 mx-auto mb-1 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">
                  PP
                </div>
                <span className="text-sm font-medium">PayPal</span>
              </button>
            </div>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          {/* Payment Forms */}
          {paymentMethod === 'stripe' ? (
            <Elements stripe={stripePromise}>
              <StripePaymentForm
                plan={plan}
                onSuccess={handleStripeSuccess}
                onError={setError}
              />
            </Elements>
          ) : (
            <PayPalScriptProvider options={{ 
              clientId: PAYPAL_CLIENT_ID,
              currency: 'EUR',
              vault: true,
              intent: 'subscription'
            }}>
              <PayPalButtons
                style={{
                  layout: 'vertical',
                  color: 'blue',
                  shape: 'rect',
                  label: 'subscribe'
                }}
                createSubscription={(data, actions) => {
                  return actions.subscription.create({
                    plan_id: `plan_${plan.id}`, // You'd have actual PayPal plan IDs
                  });
                }}
                onApprove={handlePayPalSuccess}
                onError={(err) => setError('PayPal payment failed')}
              />
            </PayPalScriptProvider>
          )}

          <p className="text-xs text-gray-500 mt-4 text-center">
            Your subscription will automatically renew each {plan.interval}. 
            You can cancel anytime from your account settings.
          </p>
        </div>
      </div>
    </div>
  );
};