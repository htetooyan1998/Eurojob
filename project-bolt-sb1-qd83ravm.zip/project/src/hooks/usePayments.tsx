import { useState, useEffect } from 'react';
import { SubscriptionPlan, UserSubscription, PaymentIntent } from '../types';
import { SUBSCRIPTION_PLANS } from '../config/payments';

export const usePayments = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createSubscription = async (
    planId: string,
    paymentMethod: 'stripe' | 'paypal',
    paymentDetails: any
  ): Promise<UserSubscription> => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call to create subscription
      await new Promise(resolve => setTimeout(resolve, 1500));

      const plan = SUBSCRIPTION_PLANS.find(p => p.id === planId);
      if (!plan) throw new Error('Plan not found');

      const subscription: UserSubscription = {
        plan: planId as 'free' | 'premium' | 'enterprise',
        status: 'active',
        startDate: new Date().toISOString(),
        endDate: planId === 'free' ? undefined : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        paymentMethod,
        subscriptionId: paymentDetails.subscriptionId || `sub_${Date.now()}`
      };

      return subscription;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create subscription';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const cancelSubscription = async (subscriptionId: string): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call to cancel subscription
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real app, you'd call your backend to cancel the subscription
      console.log('Subscription cancelled:', subscriptionId);
    } catch (err) {
      const errorMessage = 'Failed to cancel subscription';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const updatePaymentMethod = async (
    subscriptionId: string,
    paymentMethod: 'stripe' | 'paypal',
    paymentDetails: any
  ): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call to update payment method
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      console.log('Payment method updated:', { subscriptionId, paymentMethod });
    } catch (err) {
      const errorMessage = 'Failed to update payment method';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const getPaymentHistory = async (userId: string): Promise<PaymentIntent[]> => {
    setLoading(true);
    setError(null);

    try {
      // Simulate API call to get payment history
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Mock payment history
      const history: PaymentIntent[] = [
        {
          id: 'pi_1',
          amount: 19.99,
          currency: 'EUR',
          status: 'succeeded',
          paymentMethod: 'stripe',
          planId: 'premium'
        },
        {
          id: 'pi_2',
          amount: 19.99,
          currency: 'EUR',
          status: 'succeeded',
          paymentMethod: 'paypal',
          planId: 'premium'
        }
      ];

      return history;
    } catch (err) {
      const errorMessage = 'Failed to fetch payment history';
      setError(errorMessage);
      throw new Error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    createSubscription,
    cancelSubscription,
    updatePaymentMethod,
    getPaymentHistory
  };
};