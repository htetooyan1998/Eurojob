export const STRIPE_PUBLISHABLE_KEY = import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || 'pk_test_your_stripe_key_here';
export const PAYPAL_CLIENT_ID = import.meta.env.VITE_PAYPAL_CLIENT_ID || 'your_paypal_client_id_here';

export const SUBSCRIPTION_PLANS = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    currency: 'EUR',
    interval: 'month' as const,
    features: [
      'Basic job search',
      'Save up to 10 jobs',
      'Standard filters',
      'Email alerts (weekly)'
    ]
  },
  {
    id: 'premium',
    name: 'Premium',
    price: 19.99,
    currency: 'EUR',
    interval: 'month' as const,
    popular: true,
    features: [
      'Advanced job search',
      'Unlimited saved jobs',
      'Premium job listings',
      'Advanced filters',
      'Daily email alerts',
      'Application tracking',
      'Resume builder',
      'Priority support'
    ]
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: 49.99,
    currency: 'EUR',
    interval: 'month' as const,
    features: [
      'All Premium features',
      'Custom API integrations',
      'Bulk job posting',
      'Analytics dashboard',
      'Dedicated account manager',
      'Custom branding',
      'Team collaboration',
      'Advanced reporting'
    ]
  }
];