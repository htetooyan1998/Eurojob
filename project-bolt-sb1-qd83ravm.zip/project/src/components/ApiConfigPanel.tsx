import React, { useState } from 'react';
import { Settings, Plus, Trash2, Eye, EyeOff } from 'lucide-react';
import { ApiConfig } from '../types';

interface ApiConfigPanelProps {
  isOpen: boolean;
  onClose: () => void;
  configs: ApiConfig[];
  onConfigsChange: (configs: ApiConfig[]) => void;
}

export const ApiConfigPanel: React.FC<ApiConfigPanelProps> = ({
  isOpen,
  onClose,
  configs,
  onConfigsChange
}) => {
  const [newConfig, setNewConfig] = useState<Partial<ApiConfig>>({
    name: '',
    endpoint: '',
    apiKey: '',
    enabled: true
  });
  const [showApiKeys, setShowApiKeys] = useState<Record<string, boolean>>({});

  const addConfig = () => {
    if (newConfig.name && newConfig.endpoint) {
      const config: ApiConfig = {
        ...newConfig as ApiConfig,
        headers: {}
      };
      onConfigsChange([...configs, config]);
      setNewConfig({ name: '', endpoint: '', apiKey: '', enabled: true });
    }
  };

  const removeConfig = (index: number) => {
    const updatedConfigs = configs.filter((_, i) => i !== index);
    onConfigsChange(updatedConfigs);
  };

  const toggleConfig = (index: number) => {
    const updatedConfigs = configs.map((config, i) =>
      i === index ? { ...config, enabled: !config.enabled } : config
    );
    onConfigsChange(updatedConfigs);
  };

  const toggleApiKeyVisibility = (configName: string) => {
    setShowApiKeys(prev => ({ ...prev, [configName]: !prev[configName] }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Settings className="h-6 w-6 text-gray-400" />
              <h2 className="text-xl font-semibold text-gray-900">API Configuration</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            >
              ×
            </button>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Configure external job search APIs to expand your job listings.
          </p>
        </div>

        <div className="p-6">
          {/* Add New API Configuration */}
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Add New API Source</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Name
                </label>
                <input
                  type="text"
                  value={newConfig.name || ''}
                  onChange={(e) => setNewConfig({ ...newConfig, name: e.target.value })}
                  placeholder="e.g., LinkedIn Jobs API"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Endpoint
                </label>
                <input
                  type="url"
                  value={newConfig.endpoint || ''}
                  onChange={(e) => setNewConfig({ ...newConfig, endpoint: e.target.value })}
                  placeholder="https://api.example.com/jobs"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  API Key (Optional)
                </label>
                <input
                  type="password"
                  value={newConfig.apiKey || ''}
                  onChange={(e) => setNewConfig({ ...newConfig, apiKey: e.target.value })}
                  placeholder="Your API key"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <button
              onClick={addConfig}
              className="mt-4 flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Plus className="h-4 w-4" />
              <span>Add API Source</span>
            </button>
          </div>

          {/* Existing API Configurations */}
          <div>
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Configured API Sources ({configs.length})
            </h3>
            {configs.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Settings className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No API sources configured yet.</p>
                <p className="text-sm">Add your first API source above to get started.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {configs.map((config, index) => (
                  <div
                    key={index}
                    className={`p-4 border rounded-lg ${
                      config.enabled ? 'border-green-200 bg-green-50' : 'border-gray-200 bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${
                          config.enabled ? 'bg-green-500' : 'bg-gray-300'
                        }`} />
                        <h4 className="font-medium text-gray-900">{config.name}</h4>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => toggleConfig(index)}
                          className={`px-3 py-1 text-xs rounded-full ${
                            config.enabled
                              ? 'bg-green-100 text-green-800'
                              : 'bg-gray-100 text-gray-600'
                          }`}
                        >
                          {config.enabled ? 'Enabled' : 'Disabled'}
                        </button>
                        <button
                          onClick={() => removeConfig(index)}
                          className="p-1 text-red-600 hover:bg-red-100 rounded"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p><strong>Endpoint:</strong> {config.endpoint}</p>
                      {config.apiKey && (
                        <div className="flex items-center space-x-2">
                          <strong>API Key:</strong>
                          {showApiKeys[config.name] ? (
                            <span className="font-mono">{config.apiKey}</span>
                          ) : (
                            <span className="font-mono">{'•'.repeat(20)}</span>
                          )}
                          <button
                            onClick={() => toggleApiKeyVisibility(config.name)}
                            className="p-1 text-gray-400 hover:text-gray-600"
                          >
                            {showApiKeys[config.name] ? (
                              <EyeOff className="h-4 w-4" />
                            ) : (
                              <Eye className="h-4 w-4" />
                            )}
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* API Documentation */}
          <div className="mt-8 p-4 bg-blue-50 rounded-lg">
            <h4 className="font-medium text-blue-900 mb-2">API Integration Guide</h4>
            <div className="text-sm text-blue-800 space-y-2">
              <p>• Your API should return job data in JSON format</p>
              <p>• Required fields: id, title, company, location, description</p>
              <p>• Optional fields: salary, type, remote, requirements, tags</p>
              <p>• The system will automatically merge results from all enabled APIs</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};