import React from 'react';
import { Loader2, Briefcase } from 'lucide-react';
import { Job } from '../types';
import { JobCard } from './JobCard';

interface JobListProps {
  jobs: Job[];
  loading: boolean;
  error: string | null;
  onSaveJob?: (jobId: string) => void;
  savedJobs?: string[];
}

export const JobList: React.FC<JobListProps> = ({
  jobs,
  loading,
  error,
  onSaveJob,
  savedJobs = []
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Searching for jobs...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <div className="text-red-600 mb-4">
          <svg className="h-12 w-12 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <p className="text-gray-600">{error}</p>
        <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Try Again
        </button>
      </div>
    );
  }

  if (jobs.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-gray-400 mb-4">
          <Briefcase className="h-12 w-12 mx-auto" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
        <p className="text-gray-600 mb-4">
          Try adjusting your search criteria or filters to find more opportunities.
        </p>
        <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          Browse All Jobs
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-semibold text-gray-900">
          {jobs.length} {jobs.length === 1 ? 'job' : 'jobs'} found
        </h2>
        <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
          <option>Sort by relevance</option>
          <option>Sort by date</option>
          <option>Sort by salary</option>
        </select>
      </div>

      <div className="grid gap-6">
        {jobs.map((job) => (
          <JobCard
            key={job.id}
            job={job}
            onSave={onSaveJob}
            isSaved={savedJobs.includes(job.id)}
          />
        ))}
      </div>
    </div>
  );
};