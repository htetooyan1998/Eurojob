import { useState, useEffect } from 'react';
import { Job, SearchFilters, ApiConfig } from '../types';

// Mock job data for demonstration
const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Developer',
    company: 'TechCorp Amsterdam',
    location: 'Amsterdam',
    country: 'Netherlands',
    type: 'full-time',
    remote: true,
    salary: { min: 65000, max: 85000, currency: 'EUR' },
    description: 'We are looking for a senior frontend developer to join our team...',
    requirements: ['React', 'TypeScript', 'Node.js', '5+ years experience'],
    benefits: ['Health insurance', 'Flexible hours', 'Remote work'],
    postedDate: '2024-01-15',
    applicationUrl: 'https://example.com/apply/1',
    tags: ['react', 'typescript', 'frontend', 'senior']
  },
  {
    id: '2',
    title: 'UX/UI Designer',
    company: 'Design Studio Berlin',
    location: 'Berlin',
    country: 'Germany',
    type: 'full-time',
    remote: false,
    salary: { min: 55000, max: 70000, currency: 'EUR' },
    description: 'Creative UX/UI designer needed for innovative projects...',
    requirements: ['Figma', 'Adobe Creative Suite', 'User Research', '3+ years experience'],
    benefits: ['Health insurance', 'Training budget', 'Team events'],
    postedDate: '2024-01-14',
    applicationUrl: 'https://example.com/apply/2',
    tags: ['design', 'ux', 'ui', 'figma']
  },
  {
    id: '3',
    title: 'DevOps Engineer',
    company: 'CloudTech Paris',
    location: 'Paris',
    country: 'France',
    type: 'full-time',
    remote: true,
    salary: { min: 70000, max: 90000, currency: 'EUR' },
    description: 'DevOps engineer to manage our cloud infrastructure...',
    requirements: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', '4+ years experience'],
    benefits: ['Stock options', 'Health insurance', 'Remote work'],
    postedDate: '2024-01-13',
    applicationUrl: 'https://example.com/apply/3',
    tags: ['devops', 'aws', 'docker', 'kubernetes']
  },
  {
    id: '4',
    title: 'Product Manager',
    company: 'StartupHub Stockholm',
    location: 'Stockholm',
    country: 'Sweden',
    type: 'full-time',
    remote: false,
    salary: { min: 80000, max: 100000, currency: 'EUR' },
    description: 'Product manager to drive product strategy and roadmap...',
    requirements: ['Product Management', 'Agile', 'Analytics', '5+ years experience'],
    benefits: ['Equity', 'Health insurance', 'Flexible hours'],
    postedDate: '2024-01-12',
    applicationUrl: 'https://example.com/apply/4',
    tags: ['product', 'management', 'strategy', 'agile']
  }
];

export const useJobs = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const searchJobs = async (filters: Partial<SearchFilters>) => {
    setLoading(true);
    setError(null);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      let filteredJobs = [...mockJobs];
      
      if (filters.query) {
        filteredJobs = filteredJobs.filter(job =>
          job.title.toLowerCase().includes(filters.query!.toLowerCase()) ||
          job.company.toLowerCase().includes(filters.query!.toLowerCase()) ||
          job.tags.some(tag => tag.toLowerCase().includes(filters.query!.toLowerCase()))
        );
      }
      
      if (filters.location) {
        filteredJobs = filteredJobs.filter(job =>
          job.location.toLowerCase().includes(filters.location!.toLowerCase())
        );
      }
      
      if (filters.country) {
        filteredJobs = filteredJobs.filter(job =>
          job.country.toLowerCase().includes(filters.country!.toLowerCase())
        );
      }
      
      if (filters.type && filters.type.length > 0) {
        filteredJobs = filteredJobs.filter(job =>
          filters.type!.includes(job.type)
        );
      }
      
      if (filters.remote !== null && filters.remote !== undefined) {
        filteredJobs = filteredJobs.filter(job => job.remote === filters.remote);
      }
      
      if (filters.salaryMin) {
        filteredJobs = filteredJobs.filter(job =>
          job.salary && job.salary.max >= filters.salaryMin!
        );
      }
      
      setJobs(filteredJobs);
    } catch (err) {
      setError('Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  };

  const fetchJobById = async (id: string): Promise<Job | null> => {
    const job = mockJobs.find(j => j.id === id);
    return job || null;
  };

  return {
    jobs,
    loading,
    error,
    searchJobs,
    fetchJobById
  };
};