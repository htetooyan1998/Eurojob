import React from 'react';
import { X, MapPin, Briefcase, Clock, Euro, Filter } from 'lucide-react';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  filters: any;
  onFiltersChange: (filters: any) => void;
}

const europeanCountries = [
  'All Countries', 'Netherlands', 'Germany', 'France', 'Sweden', 'Denmark',
  'Norway', 'Finland', 'Belgium', 'Austria', 'Switzerland', 'Italy',
  'Spain', 'Portugal', 'United Kingdom', 'Ireland', 'Poland', 'Czech Republic'
];

const jobTypes = ['full-time', 'part-time', 'contract', 'internship'];

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose, filters, onFiltersChange }) => {
  const updateFilter = (key: string, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const toggleJobType = (type: string) => {
    const currentTypes = filters.type || [];
    const newTypes = currentTypes.includes(type)
      ? currentTypes.filter((t: string) => t !== type)
      : [...currentTypes, type];
    updateFilter('type', newTypes);
  };

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed md:static inset-y-0 left-0 z-50 w-80 bg-white border-r border-gray-200 transform transition-transform duration-300 ease-in-out
        ${isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-gray-200 md:hidden">
          <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto h-full">
          {/* Location Filter */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <MapPin className="h-5 w-5 text-gray-400" />
              <h3 className="text-sm font-medium text-gray-900">Location</h3>
            </div>
            <input
              type="text"
              value={filters.location || ''}
              onChange={(e) => updateFilter('location', e.target.value)}
              placeholder="City or region..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Country Filter */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <MapPin className="h-5 w-5 text-gray-400" />
              <h3 className="text-sm font-medium text-gray-900">Country</h3>
            </div>
            <select
              value={filters.country || ''}
              onChange={(e) => updateFilter('country', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {europeanCountries.map(country => (
                <option key={country} value={country === 'All Countries' ? '' : country}>
                  {country}
                </option>
              ))}
            </select>
          </div>

          {/* Job Type Filter */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Briefcase className="h-5 w-5 text-gray-400" />
              <h3 className="text-sm font-medium text-gray-900">Job Type</h3>
            </div>
            <div className="space-y-2">
              {jobTypes.map(type => (
                <label key={type} className="flex items-center">
                  <input
                    type="checkbox"
                    checked={(filters.type || []).includes(type)}
                    onChange={() => toggleJobType(type)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm text-gray-700 capitalize">
                    {type.replace('-', ' ')}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Remote Work Filter */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Clock className="h-5 w-5 text-gray-400" />
              <h3 className="text-sm font-medium text-gray-900">Work Style</h3>
            </div>
            <div className="space-y-2">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="remote"
                  checked={filters.remote === null}
                  onChange={() => updateFilter('remote', null)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">All</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="remote"
                  checked={filters.remote === true}
                  onChange={() => updateFilter('remote', true)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">Remote</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  name="remote"
                  checked={filters.remote === false}
                  onChange={() => updateFilter('remote', false)}
                  className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                />
                <span className="ml-2 text-sm text-gray-700">On-site</span>
              </label>
            </div>
          </div>

          {/* Salary Range Filter */}
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <Euro className="h-5 w-5 text-gray-400" />
              <h3 className="text-sm font-medium text-gray-900">Salary Range (EUR)</h3>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Minimum</label>
                <input
                  type="number"
                  value={filters.salaryMin || ''}
                  onChange={(e) => updateFilter('salaryMin', e.target.value ? parseInt(e.target.value) : null)}
                  placeholder="30,000"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-xs text-gray-500 mb-1">Maximum</label>
                <input
                  type="number"
                  value={filters.salaryMax || ''}
                  onChange={(e) => updateFilter('salaryMax', e.target.value ? parseInt(e.target.value) : null)}
                  placeholder="100,000"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>

          {/* Clear Filters */}
          <button
            onClick={() => onFiltersChange({})}
            className="w-full px-4 py-2 text-sm text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Clear All Filters
          </button>
        </div>
      </div>
    </>
  );
};